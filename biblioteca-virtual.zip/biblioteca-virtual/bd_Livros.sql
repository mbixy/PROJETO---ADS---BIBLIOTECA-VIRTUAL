CREATE DATABASE IF NOT EXISTS biblioteca;
USE biblioteca;

CREATE TABLE usuario (
    idUsuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(45) NOT NULL,
    email VARCHAR(45) NOT NULL,
    senha VARCHAR(45) NOT NULL,
    dataCadastro DATE NOT NULL,
    statusCadastro VARCHAR(15) NOT NULL
);

CREATE TABLE genero (
    idGenero INT AUTO_INCREMENT PRIMARY KEY,
    descGenero VARCHAR(45) NOT NULL
);

CREATE TABLE autores (
    idAutores INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(45) NOT NULL,
    biografia VARCHAR(255)
);

CREATE TABLE livro (
    idLivro INT AUTO_INCREMENT PRIMARY KEY,
    tituloLivro VARCHAR(45) NOT NULL,
    descLivro VARCHAR(45),
    idGenero INT NOT NULL,
    idAutor INT NOT NULL,
    dataPublicacao DATE,
    capa VARCHAR(45),
    FOREIGN KEY (idGenero) REFERENCES genero(idGenero),
    FOREIGN KEY (idAutor) REFERENCES autores(idAutores)
);

CREATE TABLE capitulo (
    idCapitulo INT AUTO_INCREMENT PRIMARY KEY,
    idLivro INT NOT NULL,
    numCapit INT NOT NULL,
    tituloCapit VARCHAR(45),
    conteudo VARCHAR(255),
    FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);

CREATE TABLE leitura (
    idLeitura INT AUTO_INCREMENT PRIMARY KEY,
    idUsuario INT NOT NULL,
    idLivro INT NOT NULL,
    dataInicio DATE NOT NULL,
    dataUltLeitura DATE,
    capitAtual INT,
    FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
    FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);

CREATE TABLE favorito (
    idFavorito INT AUTO_INCREMENT PRIMARY KEY,
    idUsuario INT NOT NULL,
    idLivro INT NOT NULL,
    dataAdicao DATE NOT NULL,
    FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
    FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);

CREATE TABLE livro_has_favorito (
    livro_idLivro INT NOT NULL,
    favorito_idFavorito INT NOT NULL,
    PRIMARY KEY (livro_idLivro, favorito_idFavorito),
    FOREIGN KEY (livro_idLivro) REFERENCES livro(idLivro),
    FOREIGN KEY (favorito_idFavorito) REFERENCES favorito(idFavorito)
);

CREATE TABLE avaliacao (
    idAvaliacao INT AUTO_INCREMENT PRIMARY KEY,
    idUsuario INT NOT NULL,
    idLivro INT NOT NULL,
    nota INT NOT NULL,
    comentario VARCHAR(255),
    dataAvaliacao DATE NOT NULL,
    FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
    FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);

CREATE TABLE leitura_has_livro (
    leitura_idLeitura INT NOT NULL,
    livro_idLivro INT NOT NULL,
    PRIMARY KEY (leitura_idLeitura, livro_idLivro),
    FOREIGN KEY (leitura_idLeitura) REFERENCES leitura(idLeitura)
);


INSERT INTO genero (descGenero) VALUES
('Ficção'),
('Fantasia'),
('Mistério'),
('Romance'),
('Adulto');


INSERT INTO autores (nome, biografia) VALUES
('J.K. Rowling', 'Autora da série Harry Potter.'),
('Agatha Christie', 'Rainha do crime, autora de muitos romances de mistério.'),
('George R.R. Martin', 'Autor de As Crônicas de Gelo e Fogo.'),
('J.R.R. Tolkien', 'Criador do universo de O Senhor dos Anéis.'),
('Malala Yousafzai', 'Ativista e autora de livros sobre educação.');


INSERT INTO livro (tituloLivro, descLivro, idGenero, idAutor, dataPublicacao, capa) VALUES
('Harry Potter e a Pedra Filosofal', 'Primeiro livro da série Harry Potter.', 1, 1, '1997-06-26', 'capa1.jpg'),
('E Poirot Foi Embora', 'Romance de mistério com Hercule Poirot.', 3, 2, '1975-10-01', 'capa2.jpg'),
('Game of Thrones', 'Primeiro livro da série As Crônicas de Gelo e Fogo.', 1, 3, '1996-08-06', 'capa3.jpg'),
('O Hobbit', 'Aventura fantástica em um mundo mágico.', 2, 4, '1937-09-21', 'capa4.jpg'),
('Eu Sou Malala', 'Autobiografia de Malala Yousafzai.', 4, 5, '2013-10-08', 'capa5.jpg');


INSERT INTO usuario (nome, email, senha, dataCadastro, statusCadastro) VALUES
('Alice Silva', 'alice@email.com', 'senha123', '2023-01-15', 'ativo'),
('Bruno Costa', 'bruno@email.com', 'senha456', '2023-01-20', 'ativo'),
('Carla Mendes', 'carla@email.com', 'senha789', '2023-02-10', 'ativo'),
('David Oliveira', 'david@email.com', 'senha321', '2023-02-15', 'ativo'),
('Eva Pereira', 'eva@email.com', 'senha654', '2023-03-01', 'ativo');


INSERT INTO leitura (idUsuario, idLivro, dataInicio, dataUltLeitura, capitAtual) VALUES
(1, 1, '2023-01-16', '2023-01-20', 5),
(2, 2, '2023-01-21', '2023-01-23', 2),
(3, 3, '2023-02-11', '2023-02-12', 1),
(4, 4, '2023-02-16', NULL, 0),
(5, 5, '2023-03-02', NULL, 0);


INSERT INTO favorito (idUsuario, idLivro, dataAdicao) VALUES
(1, 2, '2023-01-20'),
(2, 3, '2023-01-24'),
(3, 1, '2023-02-13'),
(4, 4, '2023-02-17'),
(5, 5, '2023-03-03');


INSERT INTO avaliacao (idUsuario, idLivro, nota, comentario, dataAvaliacao) VALUES
(1, 1, 5, 'Um começo incrível para a série!', '2023-01-21'),
(2, 2, 4, 'Mistério bem construído, amei!', '2023-01-24'),
(3, 3, 5, 'Não consigo esperar pela próxima temporada!', '2023-02-14'),
(4, 4, 5, 'Um clássico da literatura!', '2023-02-18'),
(5, 5, 4, 'Inspirador e emocionante.', '2023-03-04');
