function adicionarFavorito(titulo) {
    const favoritos = JSON.parse(localStorage.getItem('favoritos')) || [];
    if (!favoritos.includes(titulo)) {
        favoritos.push(titulo);
        localStorage.setItem('favoritos', JSON.stringify(favoritos));
        alert(`"${titulo}" foi adicionado aos favoritos!`);
    } else {
        alert(`"${titulo}" já está nos favoritos.`);
    }
}
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form[role="search"]');
    form.addEventListener('submit', function(event) {
        event.preventDefault();
        searchBooks();
    });
});

function searchBooks() {
    const searchInput = document.getElementById('searchInputUsuLogado').value.toLowerCase();
    const categoriaFiltro = document.getElementById('categoriaFiltroUsuLogado').value.toLowerCase();
    const livros = document.querySelectorAll('.livroUsuLogado');

    livros.forEach(livro => {
        const titulo = livro.querySelector('.tituloUsuLogado').innerText.toLowerCase();
        const autor = livro.querySelector('.autorUsuLogado').innerText.toLowerCase();

        // Aqui você pode adicionar lógica para o filtro de categoria, se necessário
        if ((titulo.includes(searchInput) || autor.includes(searchInput))) {
            livro.style.display = 'block';
        } else {
            livro.style.display = 'none';
        }
    });
}


























// Função para adicionar o livro aos favoritos
function adicionarFavorito(livroId) {
    // Aqui você pode capturar o ID do usuário, em um cenário real isso viria da sessão do usuário
    let usuarioId = 1;  // Supondo que o usuário com ID 1 está logado

    // Simulando a data de adição do favorito
    let dataAdicao = new Date().toISOString().split('T')[0];  // Ex: "2024-11-05"

    // Montando o objeto que representa o favorito
    let favorito = {
        usuarioId: usuarioId,
        livroId: livroId,
        dataAdicao: dataAdicao
    };

    // Em um cenário real, aqui seria feita uma requisição AJAX para adicionar o favorito no banco de dados
    // Por exemplo, usando fetch() ou XMLHttpRequest

    // Para fins de demonstração, vamos apenas mostrar um alerta de sucesso
    alert("O livro foi adicionado aos seus favoritos!");

    // Simulação de envio dos dados para o banco (aqui é onde você teria que fazer uma requisição para o servidor)
    // Vamos apenas imprimir no console
    console.log('Adicionando aos favoritos:', favorito);

    // Aqui você poderia usar algo como:
    // fetch('api/adicionarFavorito', {
    //    method: 'POST',
    //    headers: {
    //      'Content-Type': 'application/json'
    //    },
    //    body: JSON.stringify(favorito)
    // })
    // .then(response => response.json())
    // .then(data => {
    //    console.log('Livro adicionado aos favoritos:', data);
    //    alert("O livro foi adicionado aos seus favoritos!");
    // })
    // .catch((error) => {
    //    console.error('Erro ao adicionar favorito:', error);
    //    alert("Houve um erro ao adicionar o livro aos favoritos.");
    // });
}















const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');

// Configuração do Express
const app = express();
const port = 3000;

// Middleware
app.use(cors());  // Para permitir requisições de outros domínios (CORS)
app.use(bodyParser.json());  // Para ler JSON do corpo das requisições

// Configuração do banco de dados MySQL
const db = mysql.createConnection({
    host: 'localhost',
    user: 'root',  // Substitua com seu usuário
    password: '',  // Substitua com sua senha
    database: 'bd_biblioteca'
});

// Conectando ao banco de dados
db.connect((err) => {
    if (err) {
        console.error('Erro ao conectar ao banco de dados: ', err);
        return;
    }
    console.log('Conectado ao banco de dados MySQL');
});

// Rota para adicionar livro aos favoritos
app.post('/adicionarFavorito', (req, res) => {
    const { usuarioId, livroId } = req.body;
    
    if (!usuarioId || !livroId) {
        return res.status(400).json({ error: 'Usuário e Livro são obrigatórios' });
    }

    // Query SQL para adicionar o favorito
    const query = 'INSERT INTO favorito (idUsuario, idLivro, dataAdicao) VALUES (?, ?, CURDATE())';
    
    db.execute(query, [usuarioId, livroId], (err, result) => {
        if (err) {
            console.error('Erro ao adicionar favorito: ', err);
            return res.status(500).json({ error: 'Erro ao adicionar o livro aos favoritos' });
        }
        res.status(200).json({ message: 'Livro adicionado aos favoritos com sucesso' });
    });
});

// Iniciar o servidor
app.listen(port, () => {
    console.log(`Servidor rodando na porta ${port}`);
});

