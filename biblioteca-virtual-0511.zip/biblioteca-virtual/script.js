
document.getElementById('loginForm').addEventListener('submit', async function(event) {
    event.preventDefault(); // Impede o envio padrão do formulário
//cadastra usuário
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;
    const data_nascimento = document.getElementById('data_nascimento').value;

    // Cria o objeto com os dados do usuário
    const usuario = {
        nome: nome,
        email: email,
        senha: senha,
        data_nascimento: data_nascimento,
        dataCadastro: new Date().toISOString().split('T')[0], // Formata a data no formato YYYY-MM-DD
        statusCadastro: 'ativo'
    };

    try {
        const response = await fetch('http://localhost:3050/usuario', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(usuario)
        });

        const result = await response.json();
        if (response.ok) {
            alert('Usuário cadastrado com sucesso!');
            document.getElementById('message').innerText = 'Usuário cadastrado com sucesso!';
        } else {
            alert('Erro ao cadastrar usuário.');
            document.getElementById('message').innerText = result.message || 'Erro ao cadastrar usuário.';
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao se conectar com o servidor.');
        document.getElementById('message').innerText = 'Erro ao se conectar com o servidor.';
    }
});


