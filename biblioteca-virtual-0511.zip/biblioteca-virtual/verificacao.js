document.getElementById('verificacaoForm').addEventListener('submit', async function (event) {
    event.preventDefault(); // Impede o envio padrão do formulário

    const email = document.getElementById('email').value; // Obtém o valor do campo email
    const senha = document.getElementById('senha').value; // Obtém o valor do campo senha

    try {
        const response = await fetch('http://localhost:3050/login', { // Faz a requisição para a rota de login
            method: 'POST', // Mudando para POST
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, senha }) // Envia email e senha no corpo da requisição
        });

        const result = await response.json(); // Recebe a resposta do servidor
        if (response.ok) {
            alert(result.message); // Exibe alerta de sucesso
            document.getElementById('message').innerText = result.message; 
            // Exibe mensagem de sucesso // aslanny coloque o link aqui
            // Você pode redirecionar para outra página ou fazer outra ação ao logar
        } else {
            alert('E-mail ou senha incorreto \n Ou usuário não cadastrado');
            //document.getElementById('message').innerText = 'E-mail ou senha incorreto \n Ou usuário não cadastrado'
            //result.message; // Exibe mensagem de erro
        }
    } catch (error) {
        console.error('Erro:', error);
        document.getElementById('message').innerText = 'Erro ao se conectar com o servidor.'; // Mensagem de erro ao conectar
    }
});
