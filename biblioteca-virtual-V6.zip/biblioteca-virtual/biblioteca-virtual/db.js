// Aqui ficará o banco de dados do projeto
const mysql = require('mysql2');

// Criação da conexão
const conexao = mysql.createConnection({
    host: 'localhost',  // ou '127.0.0.1'
    user: 'root',       // seu usuário do MySQL
    password: 'root',   // sua senha do MySQL
    database: 'bd_biblioteca'  // nome do seu banco de dados
});

// Função para inserir usuário
const inserirUsuario = (usuario, callback) => {
    const query = 'INSERT INTO usuario (nome, email, senha, dataCadastro, statusCadastro, data_nascimento) VALUES (?, ?, ?, ?, ?, ?)';
    conexao.query(query, [usuario.nome, usuario.email, usuario.senha, usuario.dataCadastro, usuario.statusCadastro, usuario.data_nascimento], (erro, resultados) => {
        if (erro) {
            return callback(erro);
        }
        callback(null, resultados);
    });
};



// Função para verificar se o usuário existe
const verificarUsuario = (email, senha, callback) => {
    const query = 'SELECT * FROM usuario WHERE email = ? AND senha = ?'; // Consulta no banco
    conexao.query(query, [email, senha], (erro, resultados) => {
        if (erro) {
            return callback(erro);
        }
        callback(null, resultados); // Retorna os resultados da consulta
    });
};

// Conectando ao banco de dados
conexao.connect((erro) => {
    if (erro) {
        console.error('Erro ao conectar ao Banco: ' + erro.stack);
        return;
    }
    console.log('Conexão Efetuada: ' + conexao.threadId);
});

// Exportando a função para uso externo
module.exports = { inserirUsuario, verificarUsuario };
