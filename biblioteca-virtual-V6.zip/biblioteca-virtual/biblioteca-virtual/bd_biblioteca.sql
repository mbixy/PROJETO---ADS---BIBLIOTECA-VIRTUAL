CREATE DATABASE IF NOT EXISTS bd_biblioteca;
USE bd_biblioteca;

CREATE TABLE usuario (
idUsuario INT AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(45) NOT NULL,
email VARCHAR(45) NOT NULL,
senha VARCHAR(45) NOT NULL,
dataCadastro DATE NOT NULL,
statusCadastro VARCHAR(15) NOT NULL,
data_nascimento DATE NOT NULL
);

CREATE TABLE autores (
idAutores INT AUTO_INCREMENT PRIMARY KEY,
nome VARCHAR(45) NOT NULL,
biografia VARCHAR(255)
);

CREATE TABLE genero (
idGenero INT AUTO_INCREMENT PRIMARY KEY,
descGenero VARCHAR(45) NOT NULL
);

CREATE TABLE livro (
idLivro INT AUTO_INCREMENT PRIMARY KEY,
tituloLivro VARCHAR(45) NOT NULL,
descLivro VARCHAR(45),
idGenero INT NOT NULL,
idAutor INT NOT NULL,
dataPublicacao DATE,
capa VARCHAR(45),
FOREIGN KEY (idGenero) REFERENCES genero(idGenero),
FOREIGN KEY (idAutor) REFERENCES autores(idAutores)
);


CREATE TABLE leitura (
idLeitura INT AUTO_INCREMENT PRIMARY KEY,
idUsuario INT NOT NULL,
idLivro INT NOT NULL,
dataInicio DATE NOT NULL,
dataUltLeitura DATE,
capitAtual INT,
FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);

CREATE TABLE capitulo (
idCapitulo INT AUTO_INCREMENT PRIMARY KEY,
idLivro INT NOT NULL,
numCapit INT NOT NULL,
tituloCapit VARCHAR(45),
conteudo VARCHAR(255),
FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);


CREATE TABLE favorito (
idFavorito INT AUTO_INCREMENT PRIMARY KEY,
idUsuario INT NOT NULL,
idLivro INT NOT NULL,
dataAdicao DATE NOT NULL,
FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);

CREATE TABLE livro_has_favorito (
livro_idLivro INT NOT NULL,
favorito_idFavorito INT NOT NULL,
PRIMARY KEY (livro_idLivro, favorito_idFavorito),
FOREIGN KEY (livro_idLivro) REFERENCES livro(idLivro),
FOREIGN KEY (favorito_idFavorito) REFERENCES favorito(idFavorito)
);

CREATE TABLE avaliacao (
idAvaliacao INT AUTO_INCREMENT PRIMARY KEY,
idUsuario INT NOT NULL,
idLivro INT NOT NULL,
nota INT NOT NULL,
comentario VARCHAR(255),
dataAvaliacao DATE NOT NULL,
FOREIGN KEY (idUsuario) REFERENCES usuario(idUsuario),
FOREIGN KEY (idLivro) REFERENCES livro(idLivro)
);

CREATE TABLE leitura_has_livro (
leitura_idLeitura INT NOT NULL,
livro_idLivro INT NOT NULL,
PRIMARY KEY (leitura_idLeitura, livro_idLivro),
FOREIGN KEY (leitura_idLeitura) REFERENCES leitura(idLeitura));